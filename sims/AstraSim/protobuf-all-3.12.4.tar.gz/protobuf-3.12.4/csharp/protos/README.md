This directory contains unit test protos adapted from those in
src/google/protobuf, and C#-specific test protos for regression
tests against bugs found in the C# codegen or library.
